var searchData=
[
  ['domain_5fname_5fserver_5flookup',['domain_name_server_lookup',['../problem3_8c.html#a8ffd78e8c1cc5d1c7b03c7b568620316',1,'problem3.c']]]
];
