var searchData=
[
  ['main',['main',['../problem1_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;problem1.c'],['../problem2_8cpp.html#a5ea466849f21e6c2be4ef9b2eb8868d3',1,'main(int argc, char **argv):&#160;problem2.cpp'],['../problem3_8c.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main(int argc, char *argv[]):&#160;problem3.c'],['../problem4_8c.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main(int argc, char *argv[]):&#160;problem4.c']]]
];
